package main

import (
    "fmt"
)

func main() {
    ch1 := make(chan string)
    ch2 := make(chan string)

    go func() {
        ch1 <- "Some data from Goroutine 1"
        msg := <-ch2
        fmt.Println(msg)
    }()

    go func() {
        ch2 <- "Some data from Goroutine 2"
        msg := <-ch1
        fmt.Println(msg)
    }()

    select {}  // Question: What is the purpose of this?
} 